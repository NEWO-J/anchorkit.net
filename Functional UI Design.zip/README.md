
  # Functional UI Design

  This is a code bundle for Functional UI Design. The original project is available at https://www.figma.com/design/efONyhxlNQiVcdgVKN0ZXY/Functional-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
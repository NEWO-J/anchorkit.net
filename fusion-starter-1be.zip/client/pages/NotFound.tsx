import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col bg-anchor-navy">
      <Header />
      <main className="flex-1 flex items-center justify-center px-8 py-24">
        <div className="text-center">
          <h1 className="text-8xl font-bold text-anchor-orange mb-4">404</h1>
          <p className="text-2xl font-semibold text-anchor-purple-light mb-6">
            Page not found
          </p>
          <p className="text-anchor-text-muted mb-8 max-w-sm mx-auto">
            This page doesn't exist or has been moved.
          </p>
          <Link
            to="/"
            className="inline-flex items-center justify-center px-5 py-3 rounded-xl bg-[rgba(174,167,255,0.70)] border-2 border-white/50 text-white font-medium text-base hover:bg-[rgba(174,167,255,0.85)] transition-colors"
          >
            Return to Home
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default NotFound;

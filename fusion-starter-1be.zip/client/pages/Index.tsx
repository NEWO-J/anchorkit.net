import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ProvenanceSection from "@/components/ProvenanceSection";
import IntegrationSection from "@/components/IntegrationSection";
import Footer from "@/components/Footer";

export default function Index() {
  return (
    <div className="min-h-screen flex flex-col bg-anchor-navy">
      <Header />
      <main className="flex-1">
        <HeroSection />
        <ProvenanceSection />
        <IntegrationSection />
      </main>
      <Footer />
    </div>
  );
}

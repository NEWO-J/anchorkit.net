export default function ProvenanceSection() {
  return (
    <section className="w-full py-16 md:py-24 px-8 md:px-16">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
        {/* Left: offline proof diagram */}
        <div className="w-full lg:w-1/2 flex justify-center lg:justify-start">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/1ecc73562992fba489cde91ed113e08946dc3288?width=1322"
            alt="Offline proof diagram showing Merkle tree verification flow"
            className="w-full max-w-[560px] h-auto object-contain"
          />
        </div>

        {/* Right: text content */}
        <div className="w-full lg:w-1/2 flex flex-col items-center lg:items-start text-center lg:text-left gap-6">
          <h2 className="text-anchor-purple-light font-bold text-4xl md:text-5xl leading-[145%] tracking-[-0.96px] max-w-[620px]">
            The First Photo-Provenance With No Vendor Lock-In
          </h2>

          <p className="text-anchor-text-muted font-medium text-lg md:text-xl leading-[145%] tracking-[-0.4px] max-w-[520px]">
            After the initial submission, media verification requires{" "}
            <span className="text-white/87">zero trust</span> in AnchorKit
            infrastructure, or any third party. All it takes is an offline
            proof-bundle and an RPC call to a public Solana node.
          </p>

          <a
            href="#"
            className="inline-flex items-center justify-center px-4 py-3 rounded-xl border-2 border-white/50 bg-[rgba(174,167,255,0.10)] text-white font-medium text-lg leading-[145%] hover:bg-[rgba(174,167,255,0.20)] transition-colors mt-2"
          >
            Try The Demo App
          </a>
        </div>
      </div>
    </section>
  );
}

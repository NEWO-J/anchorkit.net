export default function Header() {
  return (
    <header className="flex items-center justify-between px-8 py-6 md:px-16 w-full">
      <a href="/" className="flex-shrink-0">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/a713f69482cb3fdd4ac95265dc8540ae7650c8d3?width=754"
          alt="AnchorKit"
          className="h-14 md:h-[82px] w-auto"
        />
      </a>
      <nav className="flex items-center gap-6 md:gap-10">
        <a
          href="#"
          className="text-anchor-orange font-medium text-base leading-[145%] tracking-[-0.08px] capitalize hover:opacity-80 transition-opacity"
        >
          Docs
        </a>
        <a
          href="#"
          className="text-anchor-orange font-medium text-base leading-[145%] tracking-[-0.08px] capitalize hover:opacity-80 transition-opacity"
        >
          Verify
        </a>
        <a
          href="#"
          className="text-anchor-orange font-medium text-base leading-[145%] tracking-[-0.08px] capitalize hover:opacity-80 transition-opacity"
        >
          Github
        </a>
      </nav>
    </header>
  );
}

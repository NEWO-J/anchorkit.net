export default function IntegrationSection() {
  return (
    <section className="w-full py-16 md:py-24 px-8 md:px-16">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12 lg:gap-8">
        {/* Left: text content */}
        <div className="w-full lg:w-1/2 flex flex-col items-start gap-6 order-2 lg:order-1">
          <h2 className="text-[#D1BAFF] font-bold text-4xl md:text-5xl leading-[145%] tracking-[-0.24px]">
            Integrates Seamlessly Into Your App
          </h2>

          <p className="text-[#A2A0A4] font-medium text-lg md:text-xl leading-[145%] tracking-[-0.1px] max-w-[480px]">
            Drop AnchorKit into your existing Android camera stack in minutes.
            The SDK hooks directly into CameraX and Camera2 pipelines — no
            rewrites required.
          </p>

          <a
            href="#"
            className="inline-flex items-center justify-center px-4 py-3 rounded-xl border-2 border-white/50 bg-[rgba(174,167,255,0.70)] text-white font-medium text-lg leading-[145%] hover:bg-[rgba(174,167,255,0.85)] transition-colors mt-2"
          >
            Read The Docs
          </a>
        </div>

        {/* Right: app screenshot */}
        <div className="w-full lg:w-1/2 flex justify-center lg:justify-end order-1 lg:order-2">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/a50fe0653532af8672cf3c3d4100d305e1054411?width=1088"
            alt="AnchorKit app integration screenshot showing camera pipeline"
            className="w-full max-w-[500px] h-auto object-contain"
          />
        </div>
      </div>
    </section>
  );
}

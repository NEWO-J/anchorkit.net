export default function HeroSection() {
  return (
    <section className="relative w-full">
      {/* Hero image */}
      <div className="relative w-full overflow-hidden border border-black">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/33627de77d91138dc3db1cd082ae80319834b449?width=2548"
          alt="AnchorKit Hero - Throwing the Anchor on Deepfakes & AI"
          className="w-full h-auto object-cover"
        />
        {/* Overlay text on top of hero image */}
        <div className="absolute inset-0 flex flex-col justify-start pt-10 pl-8 md:pl-16 md:pt-16">
          <h1 className="text-white font-bold text-3xl md:text-5xl lg:text-6xl leading-tight tracking-tight max-w-[520px]">
            Throwing the{" "}
            <span className="text-anchor-orange">Anchor</span>
            <br />
            on Deepfakes &amp; AI
          </h1>
          <div className="flex gap-4 mt-6 md:mt-8 flex-wrap">
            <a
              href="#"
              className="inline-flex items-center justify-center px-4 py-3 rounded-xl border-2 border-white/50 text-white font-medium text-base leading-[145%] hover:bg-white/10 transition-colors"
            >
              Github
            </a>
            <a
              href="#"
              className="inline-flex items-center justify-center px-4 py-3 rounded-xl bg-[rgba(174,167,255,0.70)] border-2 border-white/50 text-white font-medium text-base leading-[145%] hover:bg-[rgba(174,167,255,0.85)] transition-colors"
            >
              Verify a Photo
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
